import torch.nn as nn
from .token import TokenEmbedding
from .position import PositionalEmbedding

class GenreEmbedding(nn.Module):
    def __init__(self, num_genres, embed_size):
        super().__init__()
        self.genre_embedding = nn.Embedding(num_genres, embed_size)

    def forward(self, genre_sequence):
        return self.genre_embedding(genre_sequence)

class BERTEmbedding(nn.Module):
    """
    BERT Embedding which is composed of the following features:
        1. TokenEmbedding : normal embedding matrix for item IDs
        2. PositionalEmbedding : adding positional information using sin, cos
        3. GenreEmbedding : adding genre embeddings for each item
        4. (Optional) SegmentEmbedding : adding sentence segment information (sent_A:1, sent_B:2)

    The sum of these features is the output of BERTEmbedding
    """

    def __init__(self, vocab_size, embed_size, max_len, num_genres, dropout=0.1):
        """
        :param vocab_size: total vocab size (items)
        :param embed_size: embedding size for both tokens and genres
        :param max_len: maximum sequence length
        :param num_genres: number of genre categories
        :param dropout: dropout rate
        """
        super().__init__()
        self.token = TokenEmbedding(vocab_size=vocab_size, embed_size=embed_size)
        self.position = PositionalEmbedding(max_len=max_len, d_model=embed_size)
        self.genre_embedding = GenreEmbedding(num_genres=num_genres, embed_size=embed_size)  # Genre embedding
        # self.segment = SegmentEmbedding(embed_size=self.token.embedding_dim)  # Optional
        self.dropout = nn.Dropout(p=dropout)
        self.embed_size = embed_size

    def forward(self, sequence, seq_genres):
        """
        :param sequence: the item sequence (tensor)
        :param seq_genres: the sequence of genre IDs (tensor)
        :return: combined embedding output (item + genre + positional information)
        """
        # Token embedding + Position embedding
        token_embeddings = self.token(sequence) + self.position(sequence)  # BERT Embedding for items
        # Genre embedding
        genre_embeddings = self.genre_embedding(seq_genres)  # Genre Embedding

        # Combine item embeddings and genre embeddings (sum or concatenation can be used)
        combined_embeddings = token_embeddings + genre_embeddings  # Element-wise sum for now
        
        return self.dropout(combined_embeddings)
