from .base import BaseModel
from .bert_modules.bert import BERT

import torch
import torch.nn as nn
import torch.nn.functional as F


class BERTModel(BaseModel):
    def __init__(self, args):
        super().__init__(args)
        self.bert = BERT(args)  # Initialize the BERT model with provided arguments
        self.out = nn.Linear(self.bert.hidden, self.bert.num_items + 1)  # Output layer to predict item scores
  
    @classmethod
    def code(cls):
        return 'bert'

    def forward(self, x,genres):
        x = self.bert(x,genres)
        return x