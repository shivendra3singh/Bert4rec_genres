from .base import AbstractDataloader
from .negative_samplers import negative_sampler_factory
import random
import torch
import torch.utils.data as data_utils
import numpy as np


class BertDataloader(AbstractDataloader):
    def __init__(self, args, dataset):
        super().__init__(args, dataset)
        args.num_items = self.item_count
        self.max_len = args.bert_max_len
        self.mask_prob = args.bert_mask_prob
        self.CLOZE_MASK_TOKEN = self.item_count + 1

        code = args.train_negative_sampler_code
        train_negative_sampler = negative_sampler_factory(code, self.user_train, self.user_valid, self.user_test,
                                                          self.user_count, self.item_count,
                                                          args.train_negative_sample_size,
                                                          args.train_negative_sampling_seed,
                                                          self.save_folder)
        code = args.test_negative_sampler_code
        test_negative_sampler = negative_sampler_factory(code, self.user_train, self.user_valid, self.user_test,
                                                         self.user_count, self.item_count,
                                                         args.test_negative_sample_size,
                                                         args.test_negative_sampling_seed,
                                                         self.save_folder)

        self.train_negative_samples = train_negative_sampler.get_negative_samples()
        self.test_negative_samples = test_negative_sampler.get_negative_samples()

    @classmethod
    def code(cls):
        return 'bert'

    def get_pytorch_dataloaders(self):
        train_loader = self._get_train_loader()
        val_loader = self._get_val_loader()
        test_loader = self._get_test_loader()
        return train_loader, val_loader, test_loader

    def _get_train_loader(self):
        dataset = self._get_train_dataset()
        dataloader = data_utils.DataLoader(dataset, batch_size=self.args.train_batch_size,
                                           shuffle=True, pin_memory=True)
        return dataloader

    def _get_train_dataset(self):
        dataset = BertTrainDataset(self.user_train, self.max_len, self.mask_prob, self.CLOZE_MASK_TOKEN,self.user_count,
                                   self.item_count, self.rng, self.train_genres_seq)
        return dataset

    def _get_val_loader(self):
        return self._get_eval_loader(mode='val')

    def _get_test_loader(self):
        return self._get_eval_loader(mode='test')

    def _get_eval_loader(self, mode):
        batch_size = self.args.val_batch_size if mode == 'val' else self.args.test_batch_size
        dataset = self._get_eval_dataset(mode)
        dataloader = data_utils.DataLoader(dataset, batch_size=batch_size,
                                           shuffle=False, pin_memory=True)
        return dataloader

    def _get_eval_dataset(self, mode):
        answers = self.user_valid if mode == 'val' else self.user_test
        dataset = BertEvalDataset(self.user_train,self.user_valid, answers,self.val_genres_seq, self.max_len, self.CLOZE_MASK_TOKEN,
                                  self.test_negative_samples,self.args.genres_size,self.item_count)
        return dataset


class BertTrainDataset(data_utils.Dataset):
    def __init__(self, user_train, max_len, mask_prob, mask_token,num_user, num_items, rng, movie_genres):
        self.user_train = user_train
        self.movie_genres = movie_genres
        self.max_len = max_len
        self.mask_prob = mask_prob
        self.mask_token = mask_token
        self.num_items = num_items
        self.rng = rng
        self._all_items = set([i for i in range(1, self.num_items + 1)])
        self.num_user = num_user

    def __len__(self):
        return self.num_user

    def __getitem__(self, user): 
        
        user_seq = self.user_train[user]
        genre_seq = self.movie_genres[user]
        tokens = []
        genres_seq = []
        labels = []

        for s, g in zip(user_seq[-self.max_len:], genre_seq[-self.max_len:]):
            prob = np.random.random()
            if prob < self.mask_prob:
                prob /= self.mask_prob
                if prob < 0.8:
                    # masking
                    tokens.append(self.num_items + 1) # (index, genres)  mask_index: num_item + 1, 0: pad, 1~num_item: item index
                    genres_seq.append([1]*18)
                elif prob < 0.9:
                    # noise
                    rnd_token = self.random_neg_sampling(rated_item = user_seq, num_item_sample = 1)[0] # item random sampling
                    tokens.append(rnd_token)  
                    genres_seq.append([random.randint(0, 1) for _ in range(18)])
#                   genres_seq.append(self.movie_genres(rnd_token))
                else:
                    tokens.append(s)
                    genres_seq.append(g)
            else:
                tokens.append(s)
                genres_seq.append(g)
            labels.append(s)

        mask_len = self.max_len - len(tokens)
        
        tokens = [0] * mask_len + tokens
        genres_seq = [[0]*18] * mask_len + genres_seq
        labels = [0] * mask_len + labels
  
        return torch.LongTensor(tokens), torch.Tensor(genres_seq), torch.LongTensor(labels)

    def random_neg_sampling(self, rated_item : list, num_item_sample : int):
        nge_samples = random.sample(range(1, self.num_items + 1), num_item_sample)
        return nge_samples

class BertEvalDataset(data_utils.Dataset):
    def __init__(self, user_train,user_valid, user_answer, movie_genres, max_len, mask_token, negative_samples, genres_size,num_items):
        self.user_train = user_train
        self.user_valid = user_valid
        self.user_answer = user_answer  # Ground truth items for evaluation (like validation or test set)
        self.num_items = num_items
        self.movie_genres = movie_genres
        self.max_len = max_len
        self.mask_token = mask_token
        self.negative_samples = negative_samples  # Negative samples for each user (for evaluation)
        
        self.genres_size = genres_size  # Number of genres (dynamic)
        self.users = sorted(self.user_train.keys())  # List of users

    def __len__(self):
        print(len(self.users))
        return len(self.users)  # The dataset length is the number of users

    def __getitem__(self, user):
        num_item_sample=100
        # Get the sequence of rated items and genres for the user
        seq = (self.user_train[user] + [self.num_items + 1])[-self.max_len:] # mask last token
        genre_seq = ([self.movie_genres in self.user_train[user]] + [[1]*18])[-self.max_len:]
        padding_len = self.max_len - len(seq)
#         print(genre_seq)
        seq = [0] * padding_len + seq
        genre_seq = [[0]*18] * padding_len + genre_seq
        
        rated = self.user_train[user] + [self.user_valid[user]]
        items = [self.user_valid[user]] + BertTrainDataset.random_neg_sampling(self,rated_item = rated, num_item_sample = num_item_sample)
        
        print(items)
        print('seq',seq)
        print('genre_seq',genre_seq)
        # Return the user sequence (tokens), candidate items, and genres for the candidates
        return torch.LongTensor(seq),  torch.Tensor(genre_seq)