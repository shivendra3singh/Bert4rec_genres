from abc import *
import random


class AbstractDataloader(metaclass=ABCMeta):
    def __init__(self, args, dataset):
        self.args = args
        seed = args.dataloader_random_seed
        self.rng = random.Random(seed)
        self.save_folder = dataset._get_preprocessed_folder_path()
        dataset = dataset.load_dataset()
        self.user_train = dataset['user_train']
        self.user_valid = dataset['user_valid']
        self.user_test = dataset['user_test']
        self.train_genres_seq = dataset['train_genres_seq']
        self.val_genres_seq = dataset['val_genres_seq']
        self.test_genres_seq = dataset['test_genres_seq']
        # self.umap = dataset['umap']
        # self.smap = dataset['smap']
        self.user_count = dataset['num_user']
        print('user',self.user_count)
        self.item_count = dataset['num_item']
        print('item',self.item_count)
    @classmethod
    @abstractmethod
    def code(cls):
        pass

    @abstractmethod
    def get_pytorch_dataloaders(self):
        pass
