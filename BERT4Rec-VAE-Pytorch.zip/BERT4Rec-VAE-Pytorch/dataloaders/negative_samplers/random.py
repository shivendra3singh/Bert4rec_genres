from .base import AbstractNegativeSampler
from tqdm import trange
import numpy as np

class RandomNegativeSampler(AbstractNegativeSampler):
    @classmethod
    def code(cls):
        return 'random'

    def generate_negative_samples(self):
      assert self.seed is not None, 'Specify seed for random sampling'
      np.random.seed(self.seed)
      negative_samples = {}
      print('Sampling negative items')

      # Loop over all users and generate negative samples
      for user in trange(self.user_count):
          if user not in self.train:
              print(f"Warning: User {user} not found in train set. Skipping.")
              continue  # Skip the user if they don't exist in train
          
          # Initialize a set of seen items, considering item_id only
          seen = set(x[0] for x in self.train[user])  # Collect item_id from the tuple
          
          # Use `.get()` to avoid KeyError if the user is not in val or test
          seen.update(x[0] for x in self.val.get(user, []))  # If user not in val, return empty list
          seen.update(x[0] for x in self.test.get(user, []))  # If user not in test, return empty list

          # Sample negative items for the user
          samples = []
          for _ in range(self.sample_size):
              item = np.random.choice(self.item_count) + 1  # Random item from 1 to item_count
              while item in seen or item in samples:  # Ensure unique negative samples
                  item = np.random.choice(self.item_count) + 1
              samples.append(item)

          # Store the generated negative samples
          negative_samples[user] = samples

      return negative_samples
