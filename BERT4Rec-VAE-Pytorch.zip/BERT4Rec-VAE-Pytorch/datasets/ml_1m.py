from .base import AbstractDataset

import pandas as pd

from datetime import date
# pd.set_option('display.max_columns', None)

class ML1MDataset(AbstractDataset):
    @classmethod
    def code(cls):
        return 'ml-1m'

    @classmethod
    def url(cls):
        return 'http://files.grouplens.org/datasets/movielens/ml-1m.zip'

    @classmethod
    def zip_file_content_is_folder(cls):
        return True

    @classmethod
    def all_raw_file_names(cls):
        return ['README',
                'movies.dat',
                'ratings.dat',
                'users.dat']

    def load_ratings_df(self):
        folder_path = self._get_rawdata_folder_path()
        file_path = folder_path.joinpath('ratings.dat')
        df = pd.read_csv(file_path, sep='::', header=None,encoding='latin-1')
        df.columns = ['uid', 'sid', 'rating', 'timestamp']
        print(df)
        return df
    def load_movies_df(self):
        folder_path = self._get_rawdata_folder_path()
        file_path = folder_path.joinpath('movies.dat')
        movies = pd.read_csv(file_path, sep='::', header=None,encoding='latin-1')
        movies.columns = ['sid', 'title', 'genres']
        return movies


