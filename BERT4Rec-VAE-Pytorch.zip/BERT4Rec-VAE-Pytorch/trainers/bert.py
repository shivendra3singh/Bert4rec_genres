from .base import AbstractTrainer
from .utils import recalls_and_ndcgs_for_ks

import torch.nn as nn


class BERTTrainer(AbstractTrainer):
    def __init__(self, args, model, train_loader, val_loader, test_loader, export_root):
        super().__init__(args, model, train_loader, val_loader, test_loader, export_root)
        self.ce = nn.CrossEntropyLoss(ignore_index=0)

    @classmethod
    def code(cls):
        return 'bert'

    def add_extra_loggers(self):
        pass

    def log_extra_train_info(self, log_data):
        pass

    def log_extra_val_info(self, log_data):
        pass

    def calculate_loss(self, batch):
        tokens, genres, labels = batch  # batch contains tokens, genres, and labels

        # Use only the token sequences for the loss calculation
        logits = self.model(tokens,genres)  # B x T x V (B is batch size, T is sequence length, V is vocabulary size)

        # Reshape logits to compute cross-entropy loss over all positions in the sequence
        logits = logits.view(-1, logits.size(-1))  # (B*T) x V
        labels = labels.view(-1)  # Flatten labels to B*T

        # Cross entropy loss (ignore padding index which is 0)
        loss = self.ce(logits, labels)
        return loss

    def calculate_metrics(self, batch):
        tokens, genres, candidates, labels = batch  # batch contains tokens, genres, candidates, and labels
        
        # Get the output from the model (token predictions)
        scores = self.model(tokens,genres)  # B x T x V (B is batch size, T is sequence length, V is vocabulary size)
        
        # Use the scores for the last token in the sequence for evaluation
        scores = scores[:, -1, :]  # B x V (taking the last token's scores)
        
        # Gather the scores corresponding to the candidate items
        scores = scores.gather(1, candidates)  # B x C (C is the number of candidate items)

        # Compute recall and NDCG metrics
        metrics = recalls_and_ndcgs_for_ks(scores, labels, self.metric_ks)
        return metrics
