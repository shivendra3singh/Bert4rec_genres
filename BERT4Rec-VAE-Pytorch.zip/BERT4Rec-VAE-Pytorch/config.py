RAW_DATASET_ROOT_FOLDER = 'Data'

STATE_DICT_KEY = 'model_state_dict'
OPTIMIZER_STATE_DICT_KEY = 'optimizer_state_dict'